# `BUG-NNNNNN` — descriptive title

| Field | Value |
|---|---|
| **ID** | `BUG-NNNNNN-<userid>` — the userid suffix is the resolved signer's (`Rules-of-Rules.md` §20) |
| **Name** | short descriptive summary of the entity's purpose/impact, e.g. `password-reset-link-expired` — follows Rules of Rules naming conventions |
| **Filename** | descriptive kebab-case filename, e.g. `BUG-000012-Ab3xR9pQ-password-reset-link-expired.md` — prefer specific problem/context over generic labels like `bug.md` or `auth-issue.md` |
| **Status** | open / in-progress / fixed / wontfix / duplicate-of `BUG-xxxx` |
| **Severity** | Critical / High / Medium / Low — see scale below. **Required.** |
| **Opened** | YYYY-MM-DD |
| **Targets** | one or more rule IDs this bug violates — **required, never empty** (see `CODE-OF-CONDUCT.md` §1) |
| **Domain** | the `DOMAIN` code(s) of the targeted rule(s), from `{{RULES_DIR}}/domains/` |
| **Area** | short free-text area label |
| **Steps** | `STEP-NNNNNN` list, in creation order, opened against this bug (`Rules-of-Rules.md` §21) — empty while implementation hasn't started; not closeable as `fixed` until every listed step is `done` or `abandoned` |
| **Signed-off-by** | name of the registered user (`IAM/users/users.json`) who signed this bug — see `CODE-OF-CONDUCT.md` §2 |

## Severity scale

- **Critical** — data loss/corruption (silent or irreversible), a
  security exposure, or a failure that permanently disables a whole
  subsystem for the rest of the process's uptime (no self-recovery).
- **High** — a functional break with no workaround, or silent data
  divergence/staleness that looks healthy but isn't.
- **Medium** — validation/UX gap with a workaround, or a functional
  break confined to an edge case.
- **Low** — cosmetic, or test-coverage/tech-debt with no observed user
  impact yet.

## Description

What's wrong, in terms of the targeted rule(s) — not just symptoms.

## Reproduction

Concrete steps or inputs that trigger it. Cite a failing/missing test if
one exists.

## Expected vs actual

- **Expected** (per the targeted rule): …
- **Actual**: …

## Root cause

`file:line` pointer(s) once known.

## Fix plan

Whether the fix changes the implementation (rule stays as-is) or the rule
itself (subject to `Rules-of-Rules.md` §1 conflict check first).

## Test plan

The specific test (existing or new) that will cover this once fixed. Not
closeable as "fixed" without one.

## Related

Other `BUG-`/`REQ-`/`HK-`/`STEP-`/`TEST-` IDs, or rule IDs.
