export interface BacklogProps {
    markdown: string;
}
/**
 * Renders `development/BACKLOG.md`'s full generated content as actual
 * formatted HTML, the same way `NodeDetail`'s `DetailsSection` renders a
 * node's own backing document — `BACKLOG.md` is machine-regenerated
 * prose (`INVARIANTS.md` INV-14), never hand-edited, so there's no
 * "hand-picked field" to show instead of the whole thing. Same CSP/trust
 * posture as `NodeDetail`: content always originates from a local,
 * trusted file.
 */
export declare function Backlog({ markdown }: BacklogProps): import("react").JSX.Element;
