import type { ChainNode } from "catalyst-core";
export declare function RoadmapDetails({ node }: {
    node: ChainNode;
}): import("react").JSX.Element | null;
