import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export function RoadmapDetails({ node }) {
    if (node.kind !== "roadmap")
        return null;
    const clean = node.signedOffBy
        ? node.signedOffBy.replace(/^_+|_+$/g, "")
        : "";
    return (_jsxs("section", { children: [_jsx("h2", { children: "Roadmap" }), _jsxs("p", { children: [node.roadmapName, node.roadmapRetired ? " (retired)" : ""] }), clean ? (_jsxs("p", { children: ["Signed off by: ", _jsx("em", { children: clean })] })) : null, node.notes ? _jsx("p", { children: node.notes }) : null] }));
}
